<?php
require __DIR__ . '/vendor/autoload.php';

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\WebSocket\WsServer;
use Ratchet\Http\HttpServer;

class ChessRoom
{
    public $participants;
    public $whitePlayer;
    public $blackPlayer;
    public $currentPosition;
    public $moveList;
    public $turnMove;
    public $remainingTimeWhite;
    public $remainingTimeBlack;
    public $roomId;
    public $gameType;
    public function __construct($roomId, $gameType)
    {
        $this->participants = new \SplObjectStorage();
        $this->whitePlayer = null;
        $this->blackPlayer = null;
        $this->currentPosition = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR";
        $this->moveList = "";
        $this->remainingTimeWhite = 0;
        $this->remainingTimeBlack = 0;
        $this->roomId = $roomId;
        $this->gameType = $gameType;
        $this->turnMove = true;
    }
    public function getInformationAsString()
    {
        ob_start();
        var_dump($this);
        return ob_get_clean();
    }
    public function isWhiteSet($participant)
    {
        $answer = array(
            'type' => 'isWhiteSet',
            'isWhiteSet' => empty($this->whitePlayer)
        );
        $participant->send(json_encode($answer));
    }
    public function isBlackSet($participant)
    {
        $answer = array(
            'type' => 'isBlackSet',
            'isBlackSet' => empty($this->blackPlayer)
        );
        $participant->send(json_encode($answer));
    }
    public function setData($participant)
    {
        $answer = array(
            'type' => 'takeMove',
            'board' => $this->currentPosition,
            'turnMove' => $this->turnMove
        );
        $participant->send(json_encode($answer));
    }
    public function send($data)
    {
        foreach ($this->participants as $participant) {
            $participant->send(json_encode($data));
        }
    }
    public function takeMove($userId, $newPosition = null)
    {
        if ($userId == $this->whitePlayer || $userId == $this->blackPlayer) {
            if (isset($newPosition)) {
                $this->currentPosition = $newPosition;
                $this->turnMove = !$this->turnMove;
                //добавление хода в запись moveList
            }
            $answer = array(
                'type' => 'takeMove',
                'board' => $this->currentPosition,
                'turnMove' => $this->turnMove
            );
            $this->send($answer);
        }
    }
}
class MyWebSocketServer implements MessageComponentInterface
{
    protected $clients;
    protected $rooms;

    public function __construct()
    {
        $this->clients = new \SplObjectStorage;
        $this->rooms = [];
        echo "Server was start\n";
    }


    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);
        $conn->roomId = null;
    }
    public function onMessage(ConnectionInterface $from, $msg)
    {
        $message = json_decode($msg, true);
        if (isset($message['type'])) {
            $type = $message['type'];
            if (isset($message['roomId'])) {
                $roomId = $message['roomId'];
                if ($type == "findRoom") {
                    $answer = array(
                        'type' => "isFindRoom",
                        'roomIsFind' => array_key_exists($roomId, $this->rooms)
                    );
                    $from->send(json_encode($answer));
                    return;
                } else if ($type == "newRoom") {
                    $room = new ChessRoom($roomId, $message['gameType']);
                    $this->rooms[$roomId] = $room;
                    return;
                }
                $room = $this->rooms[$roomId];
                if (!isset($room)) {
                    return;
                }
                switch ($type) {
                    case "addUser":
                        if (!$room->participants->contains($from)) {
                            $room->participants->attach($from);
                            $playerRole = isset($message['playerRole']) ? $message['playerRole'] : 'viewer';
                            if ($playerRole == "whitePlayer") {
                                $room->whitePlayer = $message['userId'];
                            } else if ($playerRole == "blackPlayer") {
                                $room->blackPlayer = $message['userId'];
                            }
                        }
                        break;
                    case "closeRoom":
                        $this->closeRoom($roomId);
                        break;
                    case "takeMove":
                        if (isset($message['userId']) && isset($message['board'])) {
                            $room->takeMove($message['userId'], $message['board']);
                        }

                    case "getData":
                        $room->isWhiteSet($from);
                        $room->isBlackSet($from);
                        $room->setData($from);
                        break;
                    default:
                        echo "Command is not definded\n";
                }
            } else {
                echo "roomId is not definded\n" . $msg . "\n";
            }
        }
    }
    public function closeRoom($roomId)
    {
        if (isset($this->rooms[$roomId])) {
            unset($this->rooms[$roomId]);
        }
    }
    public function onClose(ConnectionInterface $conn)
    {
        $this->clients->detach($conn);
        echo "Connection closed\n";
    }
    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "An error has occurred: {$e->getMessage()}\n";
        $conn->close();
    }
}

$server = IoServer::factory(
    new HttpServer(
        new WsServer(
            new MyWebSocketServer()
        )
    ),
    8080
);

$server->run();
?>